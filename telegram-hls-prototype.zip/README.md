# Telegram HLS Prototype

Минимальный технический прототип:
Telegram Mini App → fullscreen → HLS → собственный video player.

## Запуск

```bash
npm install
npm run dev
```

Для Telegram Mini App production-like теста приложение должно быть доступно по HTTPS.

## Важно

Тестовый HLS URL в `src/App.tsx` используется только для проверки технологии.
Для проекта его нужно заменить на собственный HLS endpoint после подтверждения playback.

## Тест

1. Open Mini App.
2. WATCH TEST VIDEO.
3. Проверить fullscreen.
4. Play / Pause.
5. Seek.
6. Buffering.
7. Exit.
8. Повторить на iPhone и Android.
