import { useState } from "react";
import VideoPlayer from "./player/VideoPlayer";
import "./player/player.css";

const TEST_HLS_URL =
  "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8";

function App() {
  const [isPlayerOpen, setIsPlayerOpen] = useState(false);

  const openPlayer = async () => {
    const webApp = window.Telegram?.WebApp;

    try {
      webApp?.ready();
      webApp?.expand();
      webApp?.requestFullscreen?.();
    } catch (error) {
      console.warn("Telegram fullscreen request failed:", error);
    }

    setIsPlayerOpen(true);
  };

  const closePlayer = () => {
    try {
      window.Telegram?.WebApp?.exitFullscreen?.();
    } catch (error) {
      console.warn("Telegram fullscreen exit failed:", error);
    }

    setIsPlayerOpen(false);
  };

  if (isPlayerOpen) {
    return (
      <VideoPlayer
        src={TEST_HLS_URL}
        title="HLS Technical Test"
        onClose={closePlayer}
      />
    );
  }

  return (
    <main className="launcher">
      <button className="launcher-button" onClick={openPlayer}>
        WATCH TEST VIDEO
      </button>
    </main>
  );
}

export default App;
