export function enterTelegramFullscreen() {
  const webApp = window.Telegram?.WebApp;

  webApp?.ready();
  webApp?.expand();

  try {
    webApp?.requestFullscreen?.();
  } catch (error) {
    console.warn("Telegram fullscreen is unavailable:", error);
  }
}

export function exitTelegramFullscreen() {
  try {
    window.Telegram?.WebApp?.exitFullscreen?.();
  } catch (error) {
    console.warn("Telegram fullscreen exit failed:", error);
  }
}
